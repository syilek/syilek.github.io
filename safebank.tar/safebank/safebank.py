import sqlite3
from bottle import route, run, debug, template, static_file, request, redirect, response

import random
import html


@route('/static/<filename>')
def serve_static(filename):
	return static_file(filename, root='/home/student/safebank/static')




@route('/')
@route('/home')
def home():
    return template('home')	

@route('/test')
def test():
    htmlcode='<html><body><p>This is a test page</p></body></html>'
    return htmlcode

@route('/welcome')
def welcome():
    htmlcode='<html><body><p>Welcome to web security, %s !</p></body></html>'
    name=request.GET.get('firstname','')
    return htmlcode%html.escape(name)

@route('/welcome2')
def welcome2():
    thename=request.GET.get('firstname','')
    return template('welcome2',name=thename)



@route('/setcookie')
def setcookie():
    randomnum = random.randint(0,100)
    response.set_cookie('secret',str(randomnum))
    return 'Setting your cookie to '+str(randomnum)


@route('/getcookie')
def getcookie():
    num = request.cookies.get('secret')
    return 'Your cookie is currently '+str(num)


@route('/contact')
def contact():
    return template('contact')

@route('/location')
def location():
    return template('location')


@route('/services')
def services():
    sessionid = request.cookies.get('sessid')
    if (not sessionid):
        redirect('/login')
    user = sessionid
    conn = sqlite3.connect('safe.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?",(user,))
    result = c.fetchone()

    acctnum = result['acct']
    curr_balance = result['balance']
    
    if (not result):
        # bogus cookie, so clear it by logging out
        redirect('/logout')


    return template('services', username=user, balance=curr_balance, acct=acctnum) 


@route('/dotransfer')
def do_transfer():
    sessionid = request.cookies.get('sessid')
    if (not sessionid):
        redirect('/login')
    user = sessionid
    conn = sqlite3.connect('safe.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?",(user,))
    result = c.fetchone()
 
    if (not result):
        # bogus cookie, so clear it by logging out
        redirect('/logout')

    # transfer amt from fromacct to toacct 
    frombal = result['balance']
    amt = int(request.GET.get('amt','').strip()) 
    toacct = int(request.GET.get('toacct','').strip())

    c.execute("SELECT * FROM users WHERE acct = ?", (toacct,));
    result2 = c.fetchone() 
    if (not result2):
        return "Account does not exist"

    tobal = result2['balance']
    newfrom = frombal-amt
    newto = tobal+amt
    #print "from had %d now has %d ... to had %d now has %d"%(frombal,newfrom,tobal,newto)

    c.execute('UPDATE users SET balance=? where username = ?', (newfrom,user))
    c.execute('UPDATE users SET balance=? where acct = ?', (newto,toacct))
    conn.commit()
    conn.close()
    return template('dotransfer')

@route('/transfer')
def transfer():
    sessionid = request.cookies.get('sessid')
    if (not sessionid):
        redirect('/login')
    user = sessionid
    conn = sqlite3.connect('safe.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?",(user,))
    result = c.fetchone()
 
    if (not result):
        # bogus cookie, so clear it by logging out
        redirect('/logout')


    return template('transfer',balance=result['balance'], acct=result['acct']) 


@route('/logout')
def logout():
    response.delete_cookie('sessid')
    redirect('/login')


@route('/login')
def login():
    return template('login')

@route('/login',method='POST')
def do_login():
    username = request.POST.get('username')
    password = request.POST.get('password')
    res=check_userpw(username,password)
    if (res):
        response.set_cookie('sessid',res['username'])
        redirect('/services')
    else:
        return 'bad login info'

def check_userpw(user,pw):
    conn = sqlite3.connect('safe.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    #c.execute("SELECT * FROM users WHERE username = ? and password = ?", (user, pw))
    c.execute("SELECT * FROM users WHERE username = '"+user+"' and password = '"+pw+"'")
    result = c.fetchone()
    return result 




debug(True)
run(host='0.0.0.0')
