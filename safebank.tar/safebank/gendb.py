import sqlite3
con = sqlite3.connect('safe.db') # Warning: This file is created in the current directory
con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, acct INTEGER NOT NULL, username TEXT NOT NULL, password TEXT NOT NULL, balance INTEGER NOT NULL)")
con.execute("INSERT INTO users (acct,username,password,balance) VALUES (17642,'alice','password',150)")
con.execute("INSERT INTO users (acct,username,password,balance) VALUES (18201,'bob','qwerty',250)")
con.execute("INSERT INTO users (acct,username,password,balance) VALUES (66666,'eve','ilovebob',1050)")
con.commit()
