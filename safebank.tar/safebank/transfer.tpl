% rebase('base.tpl')
Current Balance: {{balance}}
<br/>
<br/>
<form action="/dotransfer" method="GET">
From Account: {{acct}}<br/>
To Account: <input type="text" name="toacct"/><br/>
Amount: <input type="text" name="amt"/><br/>
<input type="submit" name="sub" value="Transfer Funds"/>
</form>
<br/>
<br/>
