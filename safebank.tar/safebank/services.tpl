% rebase('base.tpl')

Welcome {{username}}! <a href="/logout">logout</a><br/>
Account Number: {{acct}}<br/>
Current Balance: {{balance}}<br/><br/>

<p>
We are committed to keeping your money safe!
</p>

<a href="/transfer">Transfer Money</a>

<br/>
<br/>
