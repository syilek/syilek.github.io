<html>
<head><title>Safebank - Your money is SAFE with us</title></head>

<body>
<center>
<a href="/home"><img border="0" src="/static/bank.png"/></a>
<br/><br/>

{{!base}}


<a href="/home">Home</a> | <a href="/services">Our Services</a> | <a href="/contact">Contact Us</a> | <a href="/location">Our Location</a>
</center>
</body>
</html>
