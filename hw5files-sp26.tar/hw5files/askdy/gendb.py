import sqlite3
con = sqlite3.connect('ask.db') # Warning: This file is created in the current directory
con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT NOT NULL, password TEXT NOT NULL, months INTEGER NOT NULL)")
con.execute("INSERT INTO users (username,password,months) VALUES ('alice','password',15)")
con.execute("INSERT INTO users (username,password,months) VALUES ('bob','qwerty',8)")
con.execute("INSERT INTO users (username,password,months) VALUES ('charlie','dog',4)")
con.commit()
