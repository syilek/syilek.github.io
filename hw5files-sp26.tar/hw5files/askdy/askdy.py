import sqlite3
import hashlib
from bottle import route, run, debug, template, static_file, request, redirect, response


@route('/static/<filename>')
def serve_static(filename):
	return static_file(filename, root='/home/student/hw5files/askdy/static')


@route('/')
@route('/home')
def home():
    return template('home')	


@route('/search')
def search():    
    html = """
<html>
<head><title>Ask Dr. Yilek - Who Needs Google?</title></head>

<body>
<center>
<a href="/home"><img border="0" src="/static/drawing.png"/></a>
<br/><br/>


<b>You asked:</b>
%s

	<br/><br/>
<b> Dr. Yilek says: </b>
	No Idea 
	<br/><br/>
	<a href="/home">Ask Dr. Yilek Something Else...</a>

</center>
</body>
</html>
"""

    q = request.GET.get('q', '').strip()
    level = int(request.GET.get('level','').strip())
    if (level == 1):
        return html%q
    elif (level == 2):
        return html%(q.replace('<script',''))
    elif (level == 3):
        return html%(q.lower().replace('script',' '))
    elif (level == 4):
        return html%(q.lower().replace('<script','').replace('<img',''))
    else: 
        return template('search', query=q)


@route('/members')
def members():
    sessionid = request.cookies.get('sessionid')
    if (not sessionid):
        redirect('/login')
    parts = sessionid.split('_')
    user = parts[0][::-1]
    hsh = parts[1]
    if (hashlib.sha1(user.encode('utf-8')).hexdigest()!=hsh):
        print('cookie hash did not work')
        redirect('/login')

    conn = sqlite3.connect('ask.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?",(user,))
    result = c.fetchone()
 
    #curr_months = result['months']
    
    if (not result):
        # bogus cookie, so clear it by logging out
        redirect('/logout')

    curr_months = result['months']

    return template('members', username=user, months=curr_months) 


@route('/purchase')
def purchase():
    sessionid = request.cookies.get('sessionid')
    if (not sessionid):
        redirect('/login')
    parts = sessionid.split('_')
    user = parts[0][::-1]
    hsh = parts[1]
    if (hashlib.sha1(user.encode('utf-8')).hexdigest()!=hsh):
        print('cookie hash did not work')
        redirect('/login')

    conn = sqlite3.connect('ask.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?",(user,))
    result = c.fetchone()
 
    if (not result):
        # bogus cookie, so clear it by logging out
        redirect('/logout')

    curr_months = result['months']
    print(curr_months)
    if (curr_months==0):
        months_to_add = request.GET.get('months', '').strip()
        c.execute("UPDATE users SET months="+months_to_add+" where username ='"+user+"'")
    else:
        months_to_add = int(request.GET.get('months', '').strip())
        new_months = curr_months + months_to_add
        c.execute('UPDATE users SET months=? where username = ?', (new_months,user))
    conn.commit()
    conn.close()
    return template('purchase', months=months_to_add)



@route('/logout')
def logout():
    response.delete_cookie('sessionid')
    redirect('/login')


@route('/login')
def login():
    return template('login')

@route('/login',method='POST')
def do_login():
    username = request.POST.get('username')
    password = request.POST.get('password')
    res=check_userpw(username,password)

    if (res):
        userpart = res['username'][::-1]
        otherpart = hashlib.sha1(res['username'].encode('utf-8')).hexdigest()
        response.set_cookie('sessionid',userpart+'_'+otherpart)
        redirect('/members')
    else:
        return 'bad login info'

def check_userpw(user,pw):
    conn = sqlite3.connect('ask.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    #c.execute("SELECT * FROM users WHERE username = ? and password = ?", (user, pw))
    query="SELECT * FROM users WHERE username = '"+user+"' and password = '"+pw+"'"
    print(query)
    result=None
    try:
        c.execute(query)
        result = c.fetchone()
    except:
        print("SQL error")
        result=None
    return result 




debug(True)
run(host='0.0.0.0')
