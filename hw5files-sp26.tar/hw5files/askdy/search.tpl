% rebase('base.tpl')

<b>You asked:</b>
{{ query }}

	<br/><br/>
<b> Dr. Yilek says: </b>
	No Idea 
	<br/><br/>
	<a href="/home">Ask Dr. Yilek Something Else...</a>



