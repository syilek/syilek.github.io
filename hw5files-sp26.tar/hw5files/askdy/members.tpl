% rebase('base.tpl')

Welcome, {{ username }} <a href="/logout">logout</a><br/><br/>

You are currently signed up for <b>{{ months }}</b> months of Ask Dr. Yilek Premium Access.
<form action="/purchase" method="GET">
<br/>
Add an additional
<select name="months">
<option value="1">1</option>
<option value="6">6</option>
<option value="12">12</option>
</select>
months to my membership. (Note: by clicking the button below you agree to the accompanying charges.)
<br/>
<input type="submit" name="submit" value="Get Premium Content" />


</form>


