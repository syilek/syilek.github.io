% rebase('base.tpl')


<form action="/search" method="GET">
Your Question: <input type="text" name="q" style="width: 400px"/>
<br/><br/>
Defense Level:
<input type="radio" name="level" checked value="1" /> 1
<input type="radio" name="level" value="2" /> 2
<input type="radio" name="level" value="3" /> 3
<input type="radio" name="level" value="4" /> 4
<input type="radio" name="level" value="5" /> 5
<br/><br/>
<input type="submit" value="Ask!" style="width: 100px"/>


</form>
<br/>
<a href="/members">Access Premium Content</a>


