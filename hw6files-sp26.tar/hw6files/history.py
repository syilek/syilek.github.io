import sqlite3
from bottle import route, run, debug, template, static_file, request, redirect, response

import random
import html
import secrets


@route('/static/<filename>')
def serve_static(filename):
	return static_file(filename, root='/home/student/hw6files/static/')




@route('/')
@route('/historyquestion')
def question():
    # Todo: fill in question.tpl with your HTML
    return template('question')	



@route('/historyresults')
def results():
    # Todo: get a code from the GET parameters and show the correct list of suggested majors   
    return ''



debug(True)
run(host='0.0.0.0')
