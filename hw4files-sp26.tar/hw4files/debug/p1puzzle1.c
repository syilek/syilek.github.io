#include <stdio.h>
#include <stdlib.h>

int secret = 555;

int main(){

	char s[64];
	int x;
	x = 0;

	
	gets(s);

	if (x){
		printf("You Win!! secret is %d \n", secret);
	} else {
		printf("You lose. \n");
	}

	return 0;
}


