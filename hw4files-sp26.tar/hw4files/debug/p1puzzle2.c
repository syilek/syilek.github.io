#include <stdio.h>

int secret = 555;

int main(){

	char s[32];
	int x;
	x = 0;
	
	gets(s);

	if (x == 39457){
		printf("You Win!! secret is %d \n", secret);
	} else {
		printf("You lose. \n");
	}

	return 0;
}


