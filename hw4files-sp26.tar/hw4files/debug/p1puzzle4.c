#include <stdio.h>

int secret = 555;

void fun(void);

int main(){

	int y;
	y = 0;
	fun();
	y++;
	if (y != 0){
		printf("You Lose\n");
	} else {
		printf("You Win!! secret is %d \n", secret);
	}
	return 0;
}

void fun(){
	char s[32];
	gets(s);
}

